# example
library(readr)
raw<-read_csv("./test-data.csv") 
scores<-fastrc2(raw,father,son,freq)
print(scores)