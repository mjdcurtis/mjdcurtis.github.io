#==============================================================================#
# Matt Curtis 28/07/22
# mjdcurtis@gmail.com
#------------------------------------------------------------------------------#
# estimates RC2 association model using the fast fixest package
#==============================================================================#
# packages

# data manipulation
library(dplyr)

# fast poisson regs
library(fixest)
#------------------------------------------------------------------------------#
fastrc2 <- function(df,
                    rowvar,
                    colvar,
                    countvar,
                    # rescale 0-1
                    rescale = TRUE,
                    # force equal row and column scores
                    # otherwise, you get two seperate scales
                    # e.g. a seperate ranking for rowss and for colss
                    forcesquare = TRUE,
                    # drop small categories
                    dropsmall = FALSE,
                    # categories with fewer than 20 are small
                    smalltol = 20,
                    # simple diagonals treatment... drop all!
                    dropalldiag = FALSE,
                    # iteration parameters
                    maxiter = 1000,
                    tol = 0.0001) {
  #------------------------------------------------------------------------------#
  # df
  rows <- eval(substitute(rowvar), df)
  cols <- eval(substitute(colvar), df)
  freq <- eval(substitute(countvar), df)
  raw <- cbind(rows, cols, freq) %>% as_tibble()
  
  #------------------------------------------------------------------------------#
  # make it square by adding the tranverse
  
  if (forcesquare == TRUE) {
    rawT <- raw %>%
      select(rows = cols,
             cols = rows,
             freqT = freq)
    table <- full_join(raw, rawT, by = c("rows", "cols")) %>%
      mutate(count = freq + freqT) %>%
      select(rowname = rows, colname = cols, count)
  } else{
    table <- raw %>%
      select(rowname = rows,
             colname = cols,
             count = freq)
  }
  
  #-----------------------------------------------------------------------------#
  # fill in zeros
  
  c <- select(table, colname) %>% distinct %>%
    mutate(spam = 1)
  
  r <- select(table, rowname) %>% distinct %>%
    mutate(spam = 1)
  
  rXc <- full_join(c, r, by = "spam") %>%
    select(-spam)
  
  table <- right_join(table, rXc, by = c("rowname", "colname")) %>%
    mutate(count = replace(count, is.na(count), 0))
  
  #----------------------------------------------------------------------------#
  # initial guess of scale is the order given
  
  c <- select(table, colname) %>% distinct %>%
    mutate(c = row_number()) %>%
    select(colname, c)
  
  r <- select(table, rowname) %>% distinct %>%
    mutate(r = row_number()) %>%
    select(rowname, r)
  
  table <- left_join(table, c, by = "colname") %>%
    left_join(r, by = "rowname")
  
  nrow <- max(table$r)
  ncol <- max(table$c)

  
  # initial sig and phi values
  table <- table %>%
    mutate(sig = (r - 1) / (nrow - 1)) %>%
    mutate(phi = (c - 1) / (ncol - 1)) %>%
    mutate(mu = sig * phi)
  
  
  #----------------------------------------------------------------------------#
  conv <- 0
  iter <- 0
  
  
  # first regression
  reg <- feglm(data = table,
               count ~ 1 | r + c,
               family = "poisson",
               glm.iter = 25)
  
  
  
  prev1 <- reg$loglik
  prev2 <- reg$loglik
  
  
  
  change <- tol * 2
  
  
  
  
  # loop until improvement of fit is less than tol
  while (conv == 0) {
    iter <- iter + 1

    # starting with given sig, estimate phi
    e1 <-
      fepois(
        data = table,
        count ~ 1 | c + r[phi],
        verbose = 0,
        glm.iter = 25
      )
    
    
    beta <- fixef(e1)[2] %>% unlist
    beta <- beta - beta[1]
    beta[1] <- NA
    
    change <- e1$loglik - prev1
    prev1 <- e1$loglik
    
    message(paste0(iter, "a ", formatC(
      digits = 2, format = "e", change
    )))
    
    # update values in table
    table <- mutate(table, signew = beta[r] / beta[nrow]) %>%
      mutate(signew = case_when(r == 1 ~ sig,
                                r != 1 ~ signew)) %>%
      mutate(sig = signew) %>%
      mutate(summu = beta[nrow] * sig)
    
    # starting with given phi, estimate sig
    e2 <-
      fepois(
        data = table,
        count ~ 1 | c[summu] + r,
        verbose = 0,
        glm.iter = 25
      )
    
    change <- e2$loglik - prev2
    prev2 <- e2$loglik
    
    message(paste0(iter, "a ", formatC(
      digits = 2, format = "e", change
    )))
    
    beta <- c(NA, e2$coefficients)
    beta <- fixef(e2)[2] %>% unlist
    beta <- beta - beta[1]
    beta[1] <- NA
    
    # update table
    table <- mutate(table, phinew = beta[c] / beta[ncol]) %>%
      mutate(phinew = case_when(c == 1 ~ phi,
                                c != 1 ~ phinew)) %>%
      mutate(phi = phinew)
    
    
    # stop the loop with error if there is an infinte value
    if (abs(change) == Inf) {
      message("Infinte change, this shouldn't happen!")
      STOP
    }
    
    # time out if it takes too long
    if (iter == maxiter) {
      message("Maximum iterations, don't trust the results!")
      conv <- 1
    }
    
    # finish when the change is within tol
    if (abs(change) < tol) {
      message("Within tol")
      conv <- 1
    }
  }
  # raw scores
  colscore <- select(table, phi, c, name = colname) %>% distinct()
  rowscore <- select(table, sig, r, name = rowname) %>% distinct()
  
  final_score <- full_join(colscore, rowscore, by = "name")
  
  #----------------------------------------------------------------------------#
  # simple rescale 0-1 
  if (rescale == TRUE) {
    scale_row <- select(final_score, name, sig) %>%
      filter(!is.na(sig)) %>%
      mutate(sig = (sig - min(sig)) / (max(sig) - min(sig))) %>%
      distinct()
    
    scale_col <- select(final_score, name, phi) %>%
      filter(!is.na(phi)) %>%
      mutate(phi = (phi - min(phi)) / (max(phi) - min(phi))) %>%
      distinct()
    
    
    final_score <- full_join(scale_row, scale_col, by = "name")
  }
  #------------------------------------------------------------------------------#
  # save
  
  names(final_score) <- c("category", "rowscore", "colscore")
  
  if (forcesquare == TRUE) {
    final_score <- select(final_score, category, score = rowscore)
  }
  return(final_score)
}
#------------------------------------------------------------------------------#
